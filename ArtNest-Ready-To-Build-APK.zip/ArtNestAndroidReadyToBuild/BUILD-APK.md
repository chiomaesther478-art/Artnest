# Build ArtNest APK with GitHub Actions

1. Create a GitHub repository and upload this entire project.
2. Make sure the workflow file is at:
   `.github/workflows/build-apk.yml`
3. Open the repository's **Actions** tab.
4. Choose **Build ArtNest APK**.
5. Click **Run workflow**.
6. When it finishes, open the workflow run and download the **ArtNest-debug-apk** artifact.
7. The artifact contains `app-debug.apk`, which can be installed on an Android phone.

The workflow installs Java 17, Android API 35/build tools 35.0.0, and Gradle 8.9 before running the Android build.
